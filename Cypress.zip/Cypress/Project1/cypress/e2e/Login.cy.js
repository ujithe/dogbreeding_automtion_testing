// <reference types= "cypress"/>

it('Assertion Demo', () =>{
    cy.visit('http://localhost/dog_breading-main/login_reg.php')

    
    cy.get(':nth-child(1) > :nth-child(1) > #email').type('abc123@gmail.com')
    cy.wait(1000)

    cy.get(':nth-child(2) > td > #password').type('1234123412')
    cy.wait(1000)

    cy.get('#content_1 > form > table > tbody > :nth-child(3) > td > input').click()
    
})
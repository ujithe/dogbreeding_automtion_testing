// <reference types= "cypress"/>

it('Assertion Demo', () =>{
    cy.visit('http://localhost/dog_breading-main/login_reg.php')

    
    cy.get('#tab_2').click()

    cy.get('#first_name').type('Ujja')
    cy.get('#last_name').type('Egodawaththa')
    cy.get(':nth-child(3) > td > #email').type('abc1123@gmail.com')
    cy.get(':nth-child(4) > td > #password').type('1234123411')
    cy.get('#phone').type('01122334567')
    cy.get('#address').type('Colombo')
    cy.get(':nth-child(7) > td > input').click()
    
})